library(testthat)
library(jcrmeta)

test_check("jcrmeta")